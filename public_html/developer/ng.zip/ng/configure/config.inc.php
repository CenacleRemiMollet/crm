<?php

$configFile = '../../../../conf/application.ini';

if(! file_exists($configFile)) {
	throw new Exception('File not found: '.$configFile);
}

$config = parse_ini_file($configFile, true);

function requireSection($array, $section) {
	global $configFile;
	if (array_key_exists($section, $array)) {
		return $array[$section];
	}
	echo '['.$section.'] not found in '.$configFile;
	exit(0);
}

?>