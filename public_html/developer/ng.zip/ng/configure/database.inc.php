<?php

$database = requireSection($config, 'database');

function database_connect() {
	global $database;
	try {
		return new PDO('mysql:host='.$database['host'].';dbname='.$database['name'].';charset=utf8', $database['user'], $database['password'], array(PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION , PDO::FETCH_OBJ));
	}	catch(Exception $e){
		print_r($e);
	}
}

?>