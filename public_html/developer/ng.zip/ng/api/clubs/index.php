<?php
header('Access-Control-Allow-Origin: *');

include('../../configure/config.inc.php');
	
if(strcasecmp('application/json', $_SERVER['HTTP_ACCEPT']) == 0) {
	include('get.json.inc.php');
}

?>