<?php

include('../json.inc.php');

// cache file
$jsonCache = './cache.json';

if(! file_exists($jsonCache)) {
	// generate cache
	
	function pushIfNotEmpty($array, $key, $value) {
		if($value && $value != '') {
			$array[$key] = $value;
		}
		return $array;
	}
	
	
	include('../../configure/database.inc.php');
	
	$db = database_connect();
	$stmt = $db -> prepare("SELECT * FROM club WHERE a_supprimer = 'N'");
	
	if($stmt->execute()) {
		$clubs = array();
		while($row = $stmt->fetch()) {
			$club = array();
			$club = pushIfNotEmpty($club, 'name', trim(ucwords(mb_strtolower($row['nom']))));
			$club = pushIfNotEmpty($club, 'city', trim(ucwords(mb_strtolower($row['ville']))));
			$club = pushIfNotEmpty($club, 'department', $row['departement'] > 0 ? trim($row['departement']) : '');
			$club = pushIfNotEmpty($club, 'country', trim(ucwords(mb_strtolower($row['pays']))));
			$club = pushIfNotEmpty($club, 'website_url', trim($row['url']));
			$club = pushIfNotEmpty($club, 'facebook_url', trim($row['url_fb']));
			$club = pushIfNotEmpty($club, 'image_url', $row['logo'] ? $_SERVER['REQUEST_SCHEME']."://".$_SERVER['SERVER_NAME']."/param_clubs/logo_club/".trim($row['logo']) : null);
			array_push($clubs, $club);
		}
	}
	$db = null;

	// write cache
	$cachePointer = fopen($jsonCache, 'w');
	fwrite($cachePointer, json_encode($clubs));
	fclose($cachePointer);
}

// read cache
echo json_response(file_get_contents($jsonCache));
?>