<?php
unlink('./cache.json');
?>